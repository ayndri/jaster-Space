@include('layouts.main.head')
  <body>
    <!-- login page start-->
    @yield('content')  
    <!-- latest jquery-->
    @include('layouts.front.script')  
  </body>
</html>
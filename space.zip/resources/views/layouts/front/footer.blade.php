<footer class="footerland">
    <div class="container">
       
        <div class="row">
            
            <div class="col-md-12"> <div class="foot-copyright">
                Copyright © 2021 NamaWeb - Powered by <a href="https://jasterweb.com">Jasterweb</a>
            </div>
           
        </div>
      </div>
    </div>
  </footer>